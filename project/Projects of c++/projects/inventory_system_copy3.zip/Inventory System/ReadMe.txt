Title: Inventory System
Description: Complete Inventory System of shop with all validation checks of String and Integers I have made my own validation checks in that project you like it.

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
